string-split0 - split on zero bytes
===================================

.. include:: string-split.rst
   :start-line: 2
